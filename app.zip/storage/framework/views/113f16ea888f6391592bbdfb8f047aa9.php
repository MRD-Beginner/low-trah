<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\custom-sneat\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>