<footer class="content-footer footer bg-footer-theme mt-auto">
    <div class="{{ isset($containerFooter) ? $containerFooter : 'container' }}">
        <div
            class="footer-container d-flex align-items-center justify-content-center text-center py-4 flex-md-row flex-column">
            <div class="text-body">
                Made with hardwork by <a href="https://github.com/MRD-Beginner">Muhammad Rizki Dalfi</a> &amp; <a
                    href="https://github.com/MRD-Beginner">Dwi Nur Indah Sari</a> ©
                <script>document.write(new Date().getFullYear())</script>,
            </div>
            <div class="d-none d-lg-inline-block">
            </div>
        </div>
    </div>
</footer>
